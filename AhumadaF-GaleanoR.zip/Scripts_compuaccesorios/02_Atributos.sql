-- La cedula solo puede contener numeros (maximo 10 digitos por el tipo de dato).
ALTER TABLE personas
ADD CONSTRAINT chk_personas_cedula
    CHECK (cedula ~ '^[0-9]+$');

-- MANTENER EMPLEADO
-- Si no se indica, un empleado nuevo queda como activo por defecto.
ALTER TABLE empleados
ALTER COLUMN actualmente_trabaja
    SET DEFAULT TRUE;

-- Un empleado no puede tener salario negativo
ALTER TABLE empleados
ADD CONSTRAINT chk_empleados_salario
    CHECK (salario_empleado > 0);


-- La comision por servicio de un tecnico debe ser mayor que cero.
ALTER TABLE tecnicos
ADD CONSTRAINT chk_tecnicos_comision
    CHECK (comision_servicio > 0);


-- La comision por venta de un vendedor debe ser mayor que cero.
ALTER TABLE vendedores
ADD CONSTRAINT chk_vendedores_comision
    CHECK (comision_venta > 0);


-- MANTENER CATALOGOS
-- El precio base de un servicio debe ser mayor o igual a cero.
ALTER TABLE catalogoDeServicios
ADD CONSTRAINT chk_servicios_precio_base
    CHECK (precio_base >= 0);


-- MANTENER PRODUCTO
-- El precio unitario de un producto debe ser mayor a cero.
ALTER TABLE productos
ADD CONSTRAINT chk_productos_precio_unitario
    CHECK (precio_unitario_producto > 0);


-- La cantidad de un producto debe ser mayor o igual que cero.
ALTER TABLE productos
ADD CONSTRAINT chk_productos_cantidad_producto
    CHECK (cantidad_producto >= 0);


-- Si no se indica, un producto nuevo queda con especificaciones vacias.
ALTER TABLE productos
ALTER COLUMN especificaciones
    SET DEFAULT '{}';


-- MANTENER PROVEEDOR
-- Si no se indica, un proveedor nuevo queda como activo por defecto.
ALTER TABLE proveedores
ALTER COLUMN actualmente_provee
    SET DEFAULT TRUE;


-- REGISTRAR VENTA
-- Si la fecha de venta no se especifica, esta se asigna automaticamente utilizando la hora actual.
ALTER TABLE ventas
ALTER COLUMN fecha_venta
    SET DEFAULT CURRENT_TIMESTAMP;


-- La cantidad de un producto en el detalle de una venta debe ser mayor que cero.
ALTER TABLE detallesDeVenta
ADD CONSTRAINT chk_detallesDeVenta_cantidad
    CHECK (cantidad > 0);


-- El precio unitario en el detalle de una venta debe ser mayor que cero.
ALTER TABLE detallesDeVenta
ADD CONSTRAINT chk_detallesDeVenta_precio_unitario
    CHECK (precio_unitario > 0);


-- El total de ventas debe ser mayor o igual a cero.
ALTER TABLE ventas
ADD CONSTRAINT chk_ventas_total
    CHECK (total_venta >= 0);

-- Si no se indica, la fecha de inicio del servicio es la fecha y hora actual por defecto.
ALTER TABLE serviciosTecnicos
ALTER COLUMN fecha_inicio_servicio
    SET DEFAULT CURRENT_TIMESTAMP;


-- Si no se indica, el estado del servicio al crearlo es 'En proceso'
ALTER TABLE serviciosTecnicos
ALTER COLUMN id_estado_servicio
    SET DEFAULT 1;


-- Si no se indica, el estado de pago al crearlo es 'No pagado'
ALTER TABLE serviciosTecnicos
ALTER COLUMN id_estado_pago
    SET DEFAULT 2;


-- Atributos JSON
ALTER TABLE productos
ADD CONSTRAINT chk_productos_especificaciones
    CHECK (
        CASE WHEN especificaciones ? 'marca'
             THEN jsonb_typeof(especificaciones->'marca') = 'string'
             ELSE TRUE END
        AND
        CASE WHEN especificaciones ? 'color'
             THEN jsonb_typeof(especificaciones->'color') = 'string'
             ELSE TRUE END
        AND
        CASE WHEN especificaciones ? 'peso_gramos'
             THEN CASE WHEN jsonb_typeof(especificaciones->'peso_gramos') = 'number'
                       THEN (especificaciones->>'peso_gramos')::numeric > 0
                       ELSE FALSE END
             ELSE TRUE END
        AND
        CASE WHEN especificaciones ? 'compatibilidad'
             THEN jsonb_typeof(especificaciones->'compatibilidad') = 'array'
             ELSE TRUE END
    );